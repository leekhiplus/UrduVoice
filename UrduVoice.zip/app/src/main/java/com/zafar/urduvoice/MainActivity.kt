package com.zafar.urduvoice

import android.app.Activity
import android.content.ContentValues
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import java.io.File

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var input: EditText
    private lateinit var voiceSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var btn: Button
    private var voices: List<Voice> = emptyList()
    private var speed = 1.0f
    private var pitch = 1.0f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        root.addView(label("Voice"))
        voiceSpinner = Spinner(this)
        root.addView(voiceSpinner)

        root.addView(label("Speed"))
        root.addView(slider { speed = 0.5f + it * 0.1f })

        root.addView(label("Pitch"))
        root.addView(slider { pitch = 0.5f + it * 0.1f })

        input = EditText(this).apply {
            hint = "اسکرپٹ یہاں پیسٹ کریں"
            textDirection = View.TEXT_DIRECTION_RTL
            gravity = Gravity.TOP or Gravity.START
            minLines = 8
            textSize = 18f
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        btn = Button(this).apply {
            text = "Generate voice"
            setOnClickListener { generate() }
        }
        root.addView(btn)

        status = TextView(this).apply { text = "Starting..." }
        root.addView(status)

        setContentView(ScrollView(this).apply { addView(root) })
        tts = TextToSpeech(this, this)
    }

    private fun label(t: String) = TextView(this).apply { text = t; setPadding(0, dp(10), 0, 0) }

    private fun slider(onChange: (Int) -> Unit) = SeekBar(this).apply {
        max = 15
        progress = 5 // = 1.0
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = onChange(p)
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    override fun onInit(code: Int) {
        if (code != TextToSpeech.SUCCESS) {
            status.text = "Text-to-speech engine failed to start."
            return
        }
        voices = (tts.voices ?: emptySet()).filter { it.locale.language == "ur" }.sortedBy { it.name }
        voiceSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, voices.map { it.name }
        )
        status.text = if (voices.isEmpty())
            "No Urdu voice found. Install Urdu in Settings > Text-to-speech output (Google Speech Services)."
        else "Ready (${voices.size} Urdu voices)"
    }

    private fun generate() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) { status.text = "Paste a script first."; return }
        val max = TextToSpeech.getMaxSpeechInputLength()
        if (text.length >= max) { status.text = "Too long (max $max characters). Split it into parts."; return }
        if (voices.isEmpty()) { status.text = "No Urdu voice installed."; return }

        tts.voice = voices[voiceSpinner.selectedItemPosition]
        tts.setSpeechRate(speed)
        tts.setPitch(pitch)

        val tmp = File(cacheDir, "tmp.wav")
        btn.isEnabled = false
        status.text = "Generating..."

        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) = save(tmp)
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) = fail("Generation failed.")
        })

        val r = tts.synthesizeToFile(text, Bundle(), tmp, "u1")
        if (r != TextToSpeech.SUCCESS) fail("Could not start generation.")
    }

    private fun save(tmp: File) {
        try {
            val name = "urdu_voice_${System.currentTimeMillis()}.wav"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "audio/wav")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/UrduVoice")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return fail("Could not create file.")
            contentResolver.openOutputStream(uri)?.use { out ->
                tmp.inputStream().use { it.copyTo(out) }
            }
            runOnUiThread {
                status.text = "Saved: Downloads/UrduVoice/$name"
                btn.isEnabled = true
            }
        } catch (e: Exception) {
            fail("Save failed: ${e.message}")
        }
    }

    private fun fail(msg: String) = runOnUiThread {
        status.text = msg
        btn.isEnabled = true
    }

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }
}
